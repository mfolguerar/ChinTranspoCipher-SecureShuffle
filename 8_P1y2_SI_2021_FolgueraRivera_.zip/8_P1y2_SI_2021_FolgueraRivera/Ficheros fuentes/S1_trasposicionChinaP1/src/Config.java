
/** Clase que sirve para recopilar la informacion proporcionada por el fichero confing.txt
 * para ser distribuida entre las clases utilizadas para cifrar y descifrar el mensaje
 * Valores por defecto ,requisitos del programa
 */
public class Config {
	private boolean traza; 
	private boolean codificar;
	private String ficheroEntrada;
	private String ficheroSalida;
	private char clave;
	private int numclave;
/**
 * Contructor parametrizado
 * @param traza
 * @param codificar
 * @param ficheroEntrada
 * @param ficheroSalida
 * @param clave
 * @param numclave
 */
	public Config(boolean traza, boolean codificar, String ficheroEntrada, String ficheroSalida, char clave,
			int numclave) {
		this.traza = traza;
		this.codificar = codificar;
		this.ficheroEntrada = ficheroEntrada;
		this.ficheroSalida = ficheroSalida;
		this.clave = clave;
		this.numclave = numclave;
	}

	public boolean isTraza() {
		return traza;
	}

	public void setTraza(boolean traza) {
		this.traza = traza;
	}

	public boolean isCodificar() {
		return codificar;
	}

	public void setCodificar(boolean codificar) {
		this.codificar = codificar;
	}

	public String getFicheroEntrada() {
		return ficheroEntrada;
	}

	public void setFicheroEntrada(String ficheroEntrada) {
		this.ficheroEntrada = ficheroEntrada;
	}

	public String getFicheroSalida() {
		return ficheroSalida;
	}

	public void setFicheroSalida(String ficheroSalida) {
		this.ficheroSalida = ficheroSalida;
	}

	public char getClave() {
		return clave;
	}

	public void setClave(char clave) {
		this.clave = clave;
	}

	public int getNumclave() {
		return numclave;
	}

	public void setNumclave(int numclave) {
		this.numclave = numclave;
	}

}
