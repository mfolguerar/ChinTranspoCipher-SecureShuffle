import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.Writer;
import java.util.ArrayList;


import java.util.Random;
/**
 * Clase utilizada para la logica del cifrado y descifrado
 * @author marco
 *
 */
public class Trasposicion {

	//Atributo que sirve para saber si tenemos que dar informacion acerca de lo ocurrido 
	boolean traza;

	public Trasposicion(boolean traza) {
		this.traza = traza;
	}




	/**
	 * Metodo que se encarga de comprobar que el fichero de entrada exista y tenga los valores optimos 
	 * para la ejecucion
	 * @param c objeto con todos los atributos recopilados del fichero config.txt
	 * @throws IOException
	 */
	protected  void cifrarLlamada(Config c) throws IOException {
		TratamientoFicheros t = new TratamientoFicheros();
		String name=c.getFicheroEntrada();
		traza=c.isTraza();
		String linea=t.leerlinea(name);
		if(t.comprobarFichero(name)) {
			if(linea==null) {
				System.out.println("------------------------Fichero vacio: se rellenara automaticamente---------");
				File archivo = new File (name);
				Writer fr = new FileWriter (archivo);
				BufferedWriter bw = new BufferedWriter(fr);
				bw.write("texto_de_ejempo_tichero_Vacio123");
				bw.close();
				 linea="texto_de_ejempo_tichero_Vacio123";
			}
			String corregido="";
			if(linea.length()>999) {
				System.out.println("-------El mensaje a cifrar supera las 999 letras ,ek mensaje se acortara a 999 caracteres-----");
				int i=0;
				while(i<999) {
					corregido=corregido+linea.charAt(i);
					i++;
				}
			}else {
				corregido=linea;
			}
			String p=t.formatearTexto(corregido);

			
				String p2=t.valdidarTexto(p);
				if(!p2.equals("")) {

					if(traza) {
						System.out.println("Clave que viene:"+corregido);
						System.out.println("Clave formateada:"+p2);
					}
					cifrar(c.getNumclave(), c.getClave(), p2,c.getFicheroSalida());	



				}else {
					System.out.println("----------------------------------error----------------------------------");
					System.out.println("El mensaje"+linea+" solo contiene simbolos que imposibilitan su comprension");
					System.out.println("-------------------------------------------------------------------------");
				}

			
		}else {
			System.out.println("----------------------------------error----------------------------------");
			System.out.println("No existe el fichero con el texto en claro para ser cifrado");
			System.out.println("-------------------------------------------------------------------------");
		}

	}


	/**
	 *  Metodo el cual deduce cuantas filas y colomunas tiene la matriz con el texto cifrado y transfroma la 
	 * matriz en un String
	 * @param name nombre del fichero de salida
	 * @param o numero de filas o columnas
	 * @param tipo  tipo de  clave f->fila  c->columna
	 * @throws IOException
	 */
	protected  void Descifrar(Config c) throws IOException {
		String name=c.getFicheroEntrada();
		traza=c.isTraza();
		int o=c.getNumclave();		
		char tipo=c.getClave();
		File archivo = new File (name);
		FileReader fr = new FileReader (archivo);
		BufferedReader br = new BufferedReader(fr);
		
		String linea;
		String solucion="";

		//error porque yo trascribia la matriz cuando solo hay que trascribir la cadena
		linea=br.readLine();
		

		char matriz[][]=HacerMatriz( o,tipo, linea);
		int numcolumnnas=matriz.length;

		if(traza)System.out.println("Mensaje a descifrar->"+linea);
		if(traza)System.out.println("-------Muestro la matriz de descifrado--------");
		if(traza)System.out.println("Clave. filas="+matriz.length+" , columnas="+matriz[0].length);



		int cont=0;
		try {
		for ( int x=0; x < matriz.length; x++) {
			for ( int y=0; y < matriz[x].length; y++) {
				
				matriz[x][y]=linea.charAt(cont);
				if(traza)System.out.print(matriz[x][y]);
				

				
				cont++;
			}
			if(traza) {
				System.out.println("");
				}
		}
		int signo=-1;

		for (int i = 0 ; i < matriz[0].length ; i++) {
			signo=signo*-1;
			for (int j = 0 ; j <matriz.length; j++) {

				if(signo<0) {
					solucion=matriz[j][matriz[0].length-i-1] +solucion  ;

				}else {
					solucion=matriz[matriz.length-j-1][matriz[0].length-i-1]+solucion;

				}
			}


		} 
		StringBuilder strb = new StringBuilder(solucion);
		solucion = strb.reverse().toString();
		System.out.println("El texto en claro obtenido del cifrado->["+linea+"] es ["+solucion+"]");
		File archivo2 = new File (c.getFicheroSalida());
		Writer fr2 = new FileWriter (archivo2);
		BufferedWriter bw = new BufferedWriter(fr2);	
		bw.write(solucion);
		bw.close();
		
		
		
		}catch(Exception e){
			
			System.out.println("--------------------------ERROR AL DESCIFRAR-----------------------------");
			System.out.println("Error al descifrar el mensaje, porque no se sabe la clave");
			System.out.println("-------------------------------------------------------------------------");	

		}

	}

	/**
	 * Metodo que crea(define) la matriz del cifrado a partir de la clave y el texto en claro
	 * @param o numero de filas o columnas
	 * @param tipo  tipo de  clave f->fila  c->columna
	 * @param palabra  palabra a cifrar ,texto en claro
	 * @return devuelve la matriz echa
	 * @throws IOException
	 */
	private  char[][] HacerMatriz(int o,char tipo,String palabra) throws IOException {
		float tam;
		//por si la palabra es contiene mas de 1000 letras(requisitos del programa)
		if(palabra.length()>1000) {
			tam=1000;
		}else {
			tam=palabra.length();
		}


		float r =tam/o;
		int c=(int) Math.ceil(r);
		int x;
		int y;
		char matriz[][];

		if(tipo=='c') {

			matriz  = new char[c][o];
			x=c;
			y=o;


		}else {

			matriz = new char[o][c];
			x=o;
			y=c;

		}
		return matriz;
	}


	/**
	 * 	
	 * Metodo que a partir de la clave( num columnas o num filas )y el texto en claro
	 * crea la matriz china para cifrar el mensaje
	 * @param o  numero defilas o columnas
	 * @param tipo  tipo de  clave f->fila  c->columna
	 * @param palabra texto en claro
	 * @param fsalida
	 * @throws IOException
	 */
	private  void cifrar(int o,char tipo,String palabra,String fsalida) throws IOException {

		ArrayList<Character> cadena = new ArrayList<Character>();
		Random random = new Random();
		TratamientoFicheros t = new TratamientoFicheros();

		float tam;
		//por si la palabra es contiene mas de 1000 letras(requisitos del programa)
		
			tam=palabra.length();
		


		float r =tam/o;
		int c=(int) Math.ceil(r);
		int x;
		int y;
		char matriz[][];

		if(tipo=='c') {

			matriz  = new char[c][o];
			x=c;
			y=o;


		}else {

			matriz = new char[o][c];
			x=o;
			y=c;

		}
		if(traza)System.out.println("Clave. filas="+matriz.length+" , columnas="+matriz[0].length);

		for(int i=0;i<palabra.length()&&i<1000;i++) {
			cadena.add(palabra.charAt(i));
		}

		int cont=0;
		int signo=-1;
		for (int i = 0 ; i < y ; i++) {
			signo=signo*-1;
			for (int j = 0 ; j < x; j++) {
				if(cont>=cadena.size()) {
					if(signo<0) {
						matriz[j][y-i-1] =  (char) (random.nextInt(26) + 'a');
					}else {
						matriz[x-j-1][y-i-1] =  (char) (random.nextInt(26) + 'a');
					}
				}
				else {
					if(signo<0) {
						matriz[j][y-i-1] =  cadena.get(cont);
						cont++;
					}else {
						matriz[x-j-1][y-i-1] = cadena.get(cont);
						cont++;
					}
				}
			}

		} 

		File archivo = new File (fsalida);
		Writer fr = new FileWriter (archivo);
		BufferedWriter bw = new BufferedWriter(fr);	


		if(traza) {
			System.out.println("----------A continuacion muestro la matriz de cifrado--------------");
		
		}
		//mostrar
		for ( x=0; x < matriz.length; x++) {
			for ( y=0; y < matriz[x].length; y++) {
				
				
				bw.write(matriz[x][y]);

				if(traza) {
					System.out.print (matriz[x][y]+"");
				}
			}
			if(traza) {
			System.out.println("");
			}
		}

			
			bw.close();
			System.out.println("--------------------------------------------------------------------");
			System.out.println("El texto en claro es->["+palabra +"]y el mensaje cifrado es->["+t.leerlinea(fsalida)+"]");
			System.out.println("--------------------------------------------------------------------");
		
		
		
		
	}
	/**
	 * * Metodo el cual recibe del fichero (entrada.txt) y el texto en claro , lo formatea y escribe en el fichero 
	 * salida.txt sin espacios y comprobando que no aparezcan simbolos extra�os
	 * @param c objeto que contiene la informacion relativa a los ficheros(el nombre)
	 * @throws IOException
	 */
	protected void formateo(Config c) throws IOException {
		TratamientoFicheros t = new TratamientoFicheros();
		String name=c.getFicheroEntrada();

		traza=c.isTraza();

		

		File archivo = new File (c.getFicheroSalida());
		Writer fr = new FileWriter (archivo);
		BufferedWriter bw = new BufferedWriter(fr);
		String linea=t.leerlinea(name);
		if(linea==null) {
			System.out.println("------------------------Fichero vacio: se rellenara automaticamente---------");
			File archivo2 = new File (name);
			Writer fr2 = new FileWriter (archivo);
			BufferedWriter bw2 = new BufferedWriter(fr);
			bw.write("texto_de_ejempo_tichero_Vacio123");
			bw.close();
			linea="texto_de_ejempo_tichero_Vacio123";
		}	
		String p=t.formatearTexto(linea);
		String corregido="";
		if(p.length()>999) {
			int i=0;
			while(i<999) {
				corregido=corregido+p.charAt(i);
				i++;
			}
		}else {
			corregido=p;
		}
			String corregido2=t.valdidarTexto(corregido);
			if(traza) {
				System.out.println("-------------------------------------------------------------------------");

				System.out.println("Clave que viene:"+corregido);
				System.out.println("Clave formateada:"+corregido2);
				System.out.println("-------------------------------------------------------------------------");

			}
			if(!corregido2.equals("")) {

				
				bw.write(corregido2);
				bw.close();

			}else {

				System.out.println("----------------------------------error----------------------------------");
				System.out.println("El mensaje"+p+" solo contiene simbolos que imposibilitan su comprension");
				System.out.println("-------------------------------------------------------------------------");
			}
		

	}









}


