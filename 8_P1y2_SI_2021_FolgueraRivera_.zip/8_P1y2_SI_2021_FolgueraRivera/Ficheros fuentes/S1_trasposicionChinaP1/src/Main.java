import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
/**
 * Clase principal usada para leer el fichero de ejecucion y hacer las llamadas a los metodos necesarios
 * @author marco
 *
 */
public class Main {
	/**
	 * Metodo principal
	 * @param args se le pasan los argumentos desde consola, String el nombre del fichero de configuracion
	 * @throws IOException
	 */
	public static void main(String[] args) throws IOException{
		
		if(args.length==0) {
			System.out.println("------------------------------------------error-------------------------------------------");
			System.out.println("--------------No se han introducido parametros de entrada---------------------------------");
			System.out.println("--------------introduce ->-h   para leer elfichero de ayuda-------------------------------");
			System.out.println("--------------introduce ->-f config.txt   para ejecutar el programa-----------------------");
			System.out.println("------------------------------------------------------------------------------------------");

		}else {
		if(args[0].charAt(1)=='f') {
			if(args.length==1) {
				System.out.println("------------------------------------------error-------------------------------------------");
				System.out.println("--------------No se han introducido el archivo de configuracion---------------------------------");
			}else {
			leerConfig(args[1]);
			}
		}else if(args[0].charAt(1)=='h') {
			info();
		}

		}
	}

	/**
	 * Metodo principal
	 * Aqui se lee el fichero deconfiguracion y se crea un objeto 
	 * configuracion que va recopilando la informacion proporcionada.
	 * Haciendo las llamadas correspondiente a los metodos de cifrado y descifrado
	 * @param nombre del fichero de configuracion
	 * @throws IOException
	 */
	@SuppressWarnings("resource")
	protected static void leerConfig(String s) throws IOException {
		
		TratamientoFicheros ta = new TratamientoFicheros();
		if(ta.comprobarFichero(s)) {

			if(ta.comprobarFichero(s)) {
				File archivo = new File (s);
				FileReader fr = new FileReader (archivo);
				BufferedReader br = new BufferedReader(fr);
				String linea;
				boolean traza=true; 
				boolean codificar=true;
				String ficheroEntrada="";
				String ficheroSalida="";
				char clave='z';
				int numclave=0;
				String numclaves="";
				boolean china=true;
				Trasposicion t = new Trasposicion(true);


				while((linea=br.readLine())!=null&&china) {
					if(linea.equals("@ traza OFF")){
						traza=false;
					}else if(linea.equals("@ codifica OFF")) {
						codificar=false;
					}
					else if(linea.equals("@ codifica OFF")) {
						codificar=false;
					}else if(linea.equals("")) {

					}
					else if(linea.charAt(0)=='#'&&traza) {
						System.out.println(linea);

					}else if(linea.length()>9&&linea.charAt(0)=='&'&&linea.charAt(9)=='e') {
						int i=17;
						ficheroEntrada="";
						while(i<linea.length()) {
							ficheroEntrada=ficheroEntrada+linea.charAt(i);
							i++;
						}
						if(traza) {
							System.out.println("Fichero de entrada establecido->"+ficheroEntrada);
						}

					}else if(linea.length()>10&&linea.charAt(0)=='&'&&linea.charAt(10)=='a') {
						int i=16;
						ficheroSalida="";
						while(i<linea.length()) {
							ficheroSalida=ficheroSalida+linea.charAt(i);
							i++;
						}
						if(traza) {
							System.out.println("Fichero de salida establecido->"+ficheroSalida);
						}
					}else if(linea.length()>5&&linea.charAt(0)=='&'&&linea.charAt(5)=='u') {
						int i=11;

						numclaves="";
						while(i<linea.length()) {
							numclaves=numclaves+linea.charAt(i);
							i++;
						}
						clave='c';
						try {
							numclave= Integer.valueOf(numclaves);

						}catch(Exception e) {
							if(traza) {
							System.out.println("!!!!!Error. parametro invalido en numero de Columnas");
							}
							numclave=3;
						}
						if(traza) {
							System.out.println("Se establece la clave a "+clave+" "+numclave);
						}
					}
					else if(linea.length()>5&&linea.charAt(0)=='&'&&linea.charAt(5)=='a') {
						int i=8;
						numclaves="";
						while(i<linea.length()) {
							numclaves=numclaves+linea.charAt(i);
							i++;
						}
						clave='f';
						try {
							numclave= Integer.valueOf(numclaves);

						}catch(Exception e) {
							if(traza) {
							System.out.println("!!!!!Error. parametro invalido en numero de Filas");
							}
							clave='c';
							numclave=3;
						}
						if(traza) {
							System.out.println("Se establece la clave a "+clave+" "+numclave);
						}
					}
					else if(linea.length()>3&&linea.charAt(0)=='&'&&linea.charAt(3)=='h') {
					
						if(clave=='z'||numclave==0) {
							if(traza) {
								System.out.println("Vamos a codificar con clave automatica columna=3");
							}
							clave='c';
							numclave=3;
						}
					
						if(!ta.comprobarFichero(ficheroEntrada)) {
							if(traza) {
								System.out.println("El fichero de entrada no existe se cambiara a entrada.txt");
							}
							ficheroEntrada="entrada.txt";
							if(!ta.comprobarFichero(ficheroEntrada)) {
								System.out.println("El fichero entrada.txt no existe, se creara uno");
							File archivo2 = new File("entrada.txt");
							BufferedWriter bw;
							bw = new BufferedWriter(new FileWriter(archivo2));
							
							}
						}
						if(!ta.comprobarFichero(ficheroSalida)) {
							if(traza) {
								System.out.println("El fichero de salida no existe se crea");
							}
						
							try {
								File archivo2 = new File(ficheroSalida);
								BufferedWriter bw;
								bw = new BufferedWriter(new FileWriter(archivo2));	
							}catch(Exception e) {
								System.out.println("Se cambiara el fichero de salida a salida.txt");
								ficheroSalida="salida.txt";
								File archivo2 = new File(ficheroSalida);
								BufferedWriter bw;
								bw = new BufferedWriter(new FileWriter(archivo2));	
							}
							
							
						}

						Config config= new Config( traza,  codificar,  ficheroEntrada,  ficheroSalida,  clave, numclave);
						if(codificar==true) {
							t.cifrarLlamada(config);
						}else {
							if(traza) {
								System.out.println("Vamos a descifrar el mensaje cifrado del fichero :"+ficheroSalida);
							}
							t.Descifrar(config);
						}
						
					}else if(linea.length()>4&&linea.charAt(0)=='&'&&linea.charAt(5)=='m') {


						
						if(traza) {
							System.out.println("Vamos a formatear el contenido del fichero :"+ficheroEntrada);
						}
						if(!ta.comprobarFichero(ficheroEntrada)) {
							if(traza) {
								System.out.println("El fichero de entrada no existe se cambiara a entrada.txt");
							}
							ficheroEntrada="entrada.txt";
							if(!ta.comprobarFichero(ficheroEntrada)) {
							System.out.println("El fichero entrada.txt no existe, se creara uno");
							File archivo2 = new File("entrada.txt");
							BufferedWriter bw;
							bw = new BufferedWriter(new FileWriter(archivo2));
							
							}
						}
						if(!ta.comprobarFichero(ficheroSalida)) {
							if(traza) {
								System.out.println("El fichero de salida no existe se se creara");
							}
						
							try {
								File archivo2 = new File(ficheroSalida);
								BufferedWriter bw;
								bw = new BufferedWriter(new FileWriter(archivo2));	
							}catch(Exception e) {
								System.out.println("Se cambiara el fichero de salida a salida.txt");
								ficheroSalida="salida.txt";
								File archivo2 = new File(ficheroSalida);
								BufferedWriter bw;
								bw = new BufferedWriter(new FileWriter(archivo2));	
							}
						}
						Config config= new Config( traza,  codificar,  ficheroEntrada,  ficheroSalida,  clave, numclave);
						t.formateo(config);

					}else {
						if(traza==true&&linea.charAt(0)!='&'&&linea.charAt(0)!='@'&&linea.charAt(0)!='#') {
							System.out.println("Linea ["+linea+"] no prevista");
						}
					}

				}



			}else {
				System.out.println("------------------------Fichero vacio------------------------");
			}
		}else {	
			System.out.println("----------------------------------error----------------------------------");
			System.out.println("No existe el fichero de configuracion con el nombre: "+s);
			System.out.println("-------------------------------------------------------------------------");	
		}


	}
	/**
	 * Metodo el cual lee el fchero leeme.txt el cual contiene la informacion necesaria
	 * para ejecutar las practica correctamente
	 * @throws IOException
	 */
	private static void info() throws IOException {
		File file = new File("leeme.txt");
		if (!file.exists()) {
			System.out.println("El fichero Leeme con informacion de ejecucion no existe");
		}else {
			FileReader fr;
			try {
				fr = new FileReader (file);
				BufferedReader br = new BufferedReader(fr);
				String linea;
				while((linea=br.readLine())!=null) {
					System.out.println(linea);
				}
			} catch (FileNotFoundException e ) {
				e.printStackTrace();
			}			
		}

	}

}
